	
	var program = ['HTML', 'CSS', 'JavaScript', 'PHP', 'MeanStack'],
    lev = [9, 10, 9, 4, 3],
	
    chart,
    width = 350,
    bar_height = 20,
    height = bar_height * program.length;
var left_width = 100;
var color = d3.scale.category10();
var x, y;
x = d3.scale.linear()
   .domain([0, d3.max(lev)])
   .range([0, width]);

y = function(i) { return bar_height * i; }

chart = d3.select($("#searchVolume")[0])
  .append('svg')
  .attr('class', 'chart')
  .attr('width', left_width + width)
  .attr('height', height);

chart.selectAll("rect")
  .data(lev)
  .enter().append("rect")
  .attr("x", left_width)
  .attr("y",  function(d, i) { return y(i);})
  .attr("fill", function (d, i){ return color(i);})
  .attr("width", x)
  .attr("height", bar_height);
  
chart.selectAll("text.score")
  .data(lev)
  .enter().append("text")
  .attr("x", function(d) { return x(d) + left_width; })
  .attr("y", function(d, i) { return y(i) + bar_height / 2;} )
  .attr("dx", -5)
  .attr("dy", ".36em")
  .attr("text-anchor", "end")
  .attr('class', 'score')
  .text(String);

chart.selectAll("text.name")
  .data(program)
  .enter().append("text")
  .attr("x", left_width / 2)
  .attr("y", function(d, i){ return y(i) +bar_height/2; } )
  .attr("dx", 5)
  .attr("dy", ".36em")
  .attr("text-anchor", "middle")
  .attr('class', 'name')
  .text(String);
  
  
  
var softwares = ['Photoshop', 'Illustrator', 'Dreamweaver', 'Premiere Pro', 'Maya 3D', 'Microsoft Word', 'Microsoft Excel', 'PowerPoint'],
    level = [9, 7, 10, 4, 4, 10, 8, 10],
    mygraph,
    width = 350,
    bar_height = 20,
    height = bar_height * softwares.length;
var left_width = 100;
var color = d3.scale.category10();

var gap = 2, yRangeband;
yRangeband = bar_height + 2 * gap;
var x, y;
x = d3.scale.linear()
   .domain([0, d3.max(level)])
   .range([0, width]);

y = function(i) { return yRangeband * i; }

mygraph = d3.select($("#graph")[0])
  .append('svg')
  .attr('class', 'mygraph')
  .attr('width', left_width + width +40)
  .attr('height', (bar_height + gap *2)*softwares.length +30);

mygraph.selectAll("rect")
  .data(level)
  .enter().append("rect")
  .attr("x", left_width +10)
  .attr("y",  function(d, i) { return y(i) + gap;})
  .attr("fill", function (d, i){ return color(i);})
  .attr("width", x)
  .attr("height", bar_height);

mygraph.selectAll("text.score")
  .data(level)
  .enter().append("text")
  .attr("x", function(d) { return x(d) + left_width +5; })
  .attr("y", function(d, i) { return y(i) + yRangeband / 2;} )
  .attr("dx", -5)
  .attr("dy", ".36em")
  .attr("text-anchor", "end")
  .attr('class', 'score')
  .text(String);

mygraph.selectAll("text.name")
  .data(softwares)
  .enter().append("text")
  .attr("x", left_width/2)
  .attr("y", function(d, i){ return y(i) +yRangeband/2; } )
  .attr("dx", 5)
  .attr("dy", ".36em")
  .attr("text-anchor", "middle")
  .attr('class', 'name')
  .text(String);