<?php
	mysql_connect('sulley.cah.ucf.edu','th353996','Dtlove65') or die(mysql_error());
	mysql_select_db('th353996') or die ("cannot select db");
?>