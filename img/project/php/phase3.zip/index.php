<html>
<head>
<title>Phase 3 </title>
<link rel="stylesheet" href="css/style.css"></link>
</head>
<body>

<?php include 'config.php'; ?>

<?php include 'function.php';?>

<?php include 'header.php';?>

<div class="container">
</div>
</body>
</html>